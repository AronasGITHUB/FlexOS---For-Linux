# Welcome to FlexOS's code, check here if there are errors.
# "!" at the end of comments means the reason for error.
# "\/" means commenting on a specific line of code below.
clear 
echo Welcome to FlexOS 1.0 devbeta! An operating system designed for the linux terminal.
echo -----------------------------------------------------------------------------
# \/ your linux name probably does not exist. !
echo Whats your linux username?
read linuxname
# \/ the system files doesnt exist. !
echo Searching for System files...
cd /home/$linuxname/FlexOS/system
chmod +x 1.sh
chmod +x 2.sh
chmod +x 3.sh
chmod +x 4.sh
chmod +x 5.sh
chmod +x 6.sh
chmod +x 7.sh
chmod +x cdir.sh
chmod +x fmexit.sh
ls 
sleep 3
echo Done
sleep 2
echo Going to bootup...
cd /home/$linuxname/FlexOS/system/bootup
chmod +x flexstart.sh
chmod +x flexsafe.sh
chmod +x flexoff.sh
sleep 5
clear
sleep 3
echo FlexOS bootup
echo -------------
echo flexstart - Starts FlexOS
echo flexsafe - Enters safe mode
echo flexoff - Turns off FlexOS
echo
read bootup
./$bootup.sh
                           


                                                 
                                                 


                                                 
                                                 


                                                            



                               
                               

                               
                                                                                        
                                                                                                    
