cd leave
echo What do you want FlexOS to do?
echo [1] Shutdown
echo [2] Reboot
echo [3] Logout/Lock
echo 
read leave
./$leave.sh
