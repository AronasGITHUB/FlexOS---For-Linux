clear
echo Rebooting FlexOS...
sleep 5
cd -
./FlexOS.sh
