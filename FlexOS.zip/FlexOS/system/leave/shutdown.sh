clear
echo Shutting down FlexOS...
sleep 5
clear
exit
