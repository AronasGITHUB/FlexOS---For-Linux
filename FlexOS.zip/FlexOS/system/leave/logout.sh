clear 
echo Logging out...
cd - 
cd bootup
./flexstart.sh
