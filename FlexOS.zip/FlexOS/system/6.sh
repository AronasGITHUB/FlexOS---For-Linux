echo Whats your linux name?
read linuxname
cd /home/$linuxname/snap
firefox
