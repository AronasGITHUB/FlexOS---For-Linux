# You can only chang directories once. !
echo Choose directory to change..
read dr
cd $dr
clear
pwd
echo
ls
echo
echo [fmexit] Exit [cdir] Change directory
read input
./$input.sh
