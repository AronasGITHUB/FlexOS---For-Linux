clear
# \/ Your linux name doesnt exist. !
echo For verification, whats your linux name?
read linuxname
cd /home/$linuxname/FlexOS/system
clear
echo Login
echo -----
# \/ Your name isnt typed. !
echo Choose a name...
read flexname
# \/ Your password isnt typed. !
echo Choose a password...
read flexpass
clear
echo Loading FlexOS, please wait...
sleep 5
clear
echo FlexOS - && date
echo ---------------------
# \/ Your name isnt typed. !
echo Welcome, $flexname!
echo [1] All programs
echo [2] FlexOS Manual
echo [3] File Manager
echo [4] Settings
echo [5] Leave
echo
echo
echo ----------------------------------------------
echo [1] All Programs [6] Browser [7] Time and Date
# \/ Your number isnt displayed. !
read desktopnumber
./$desktopnumber.sh
