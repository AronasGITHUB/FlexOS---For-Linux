clear 
echo Turning off FlexOS...
sleep 5
clear
exit
