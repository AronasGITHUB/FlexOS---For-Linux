echo This will send you back to the login screen, for verification purposes.
echo enter your linux name...
read linuxname
cd /home/$linuxname/FlexOS/system/bootup
sleep 5
./flexstart.sh
