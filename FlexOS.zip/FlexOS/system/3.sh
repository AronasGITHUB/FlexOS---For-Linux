clear
echo for verification, whats your linux name?
read linuxname
clear
cd /home/$linuxname/FlexOS/system
pwd
echo
ls
echo
echo [fmexit] Exit [cdir] directory change
read input
./$input.sh
