clear
echo Settings coming soon...
echo Version 1.0 devbeta
sleep 5
cd bootup
./flexstart.sh
