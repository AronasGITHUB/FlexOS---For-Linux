clear 
echo Programs coming soon!
sleep 5
cd bootup
./flexstart.sh
