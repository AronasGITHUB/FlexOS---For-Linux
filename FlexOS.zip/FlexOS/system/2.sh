clear
echo Welcome to the FlexOS manual!
echo -----------------------------
echo Coming soon...
echo Version: 1.0 devbeta
echo
echo Press enter to go back...
read input
cd bootup
./flexstart.sh
